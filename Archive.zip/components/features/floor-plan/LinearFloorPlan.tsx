"use client";

import { useState, useMemo } from "react";
import Link from "next/link";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { FloorPlanLegend } from "./FloorPlanLegend";
import { Unit, Tenant, Lease, Floor } from "@/types";
import { UNIT_STATUS_LABELS } from "@/lib/constants";
import {
  Users,
  ExternalLink,
  ArrowUpDown,
  LayoutList,
  Grid3X3,
  Maximize2,
  FileText,
} from "lucide-react";
import {
  Tooltip,
  TooltipContent,
  TooltipProvider,
  TooltipTrigger,
} from "@/components/ui/tooltip";

interface UnitWithDetails extends Unit {
  tenant?: Tenant | null;
  lease?: Lease | null;
}

interface FloorWithUnits extends Floor {
  units: UnitWithDetails[];
}

interface LinearFloorPlanProps {
  propertyId: string;
  propertyName: string;
  floors: FloorWithUnits[];
  selectedFloorId: string | null;
  onFloorSelect: (floorId: string) => void;
}

type SortOption = "unit_number" | "area_desc" | "area_asc" | "rent_desc" | "rent_asc" | "status";
type ViewMode = "linear" | "proportional";

const STATUS_COLORS = {
  vacant: "bg-blue-50 border-blue-400 hover:bg-blue-100",
  occupied: "bg-green-50 border-green-400 hover:bg-green-100",
  maintenance: "bg-yellow-50 border-yellow-400 hover:bg-yellow-100",
  reserved: "bg-purple-50 border-purple-400 hover:bg-purple-100",
};

export function LinearFloorPlan({
  propertyId,
  propertyName,
  floors,
  selectedFloorId,
  onFloorSelect,
}: LinearFloorPlanProps) {
  const [sortBy, setSortBy] = useState<SortOption>("unit_number");
  const [viewMode, setViewMode] = useState<ViewMode>("proportional");

  const currentFloor = floors.find((f) => f.id === selectedFloorId);

  const sortedUnits = useMemo(() => {
    if (!currentFloor) return [];

    const units = [...currentFloor.units];

    switch (sortBy) {
      case "area_desc":
        return units.sort((a, b) => (b.area_sqm || 0) - (a.area_sqm || 0));
      case "area_asc":
        return units.sort((a, b) => (a.area_sqm || 0) - (b.area_sqm || 0));
      case "rent_desc":
        return units.sort((a, b) => b.monthly_rent - a.monthly_rent);
      case "rent_asc":
        return units.sort((a, b) => a.monthly_rent - b.monthly_rent);
      case "status":
        const statusOrder = { vacant: 0, reserved: 1, occupied: 2, maintenance: 3 };
        return units.sort((a, b) => statusOrder[a.status] - statusOrder[b.status]);
      default:
        return units.sort((a, b) => a.unit_number.localeCompare(b.unit_number));
    }
  }, [currentFloor, sortBy]);

  const maxArea = useMemo(() => {
    if (!currentFloor) return 100;
    return Math.max(...currentFloor.units.map((u) => u.area_sqm || 50), 50);
  }, [currentFloor]);

  const totalArea = useMemo(() => {
    if (!currentFloor) return 0;
    return currentFloor.units.reduce((sum, u) => sum + (u.area_sqm || 0), 0);
  }, [currentFloor]);

  const statusCounts = useMemo(() => {
    if (!currentFloor) return { vacant: 0, occupied: 0, maintenance: 0, reserved: 0 };
    return currentFloor.units.reduce(
      (acc, u) => {
        acc[u.status]++;
        return acc;
      },
      { vacant: 0, occupied: 0, maintenance: 0, reserved: 0 }
    );
  }, [currentFloor]);

  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat("mn-MN").format(amount) + "₮";
  };

  const getProportionalWidth = (unit: Unit) => {
    if (viewMode === "linear") return undefined;
    const area = unit.area_sqm || 50;
    const minWidth = 100;
    const maxWidth = 300;
    return Math.max(minWidth, Math.min(maxWidth, (area / maxArea) * maxWidth));
  };

  return (
    <div className="space-y-4">
      {/* Header */}
      <div className="flex flex-wrap items-center justify-between gap-4">
        {/* Floor Selection Tabs */}
        <div className="flex gap-1 rounded-lg bg-gray-100 p-1">
          {floors.map((floor) => (
            <button
              key={floor.id}
              onClick={() => onFloorSelect(floor.id)}
              className={`px-4 py-2 rounded-md text-sm font-medium transition-colors ${
                selectedFloorId === floor.id
                  ? "bg-white text-blue-600 shadow-sm"
                  : "text-gray-600 hover:text-gray-900"
              }`}
            >
              {floor.name || `${floor.floor_number}F`}
            </button>
          ))}
        </div>

        {/* Controls */}
        <div className="flex items-center gap-3">
          {/* View Mode Toggle */}
          <div className="flex gap-1 rounded-lg border p-1">
            <Button
              size="sm"
              variant={viewMode === "proportional" ? "default" : "ghost"}
              onClick={() => setViewMode("proportional")}
              className="h-8"
            >
              <Maximize2 className="h-4 w-4 mr-1" />
              Талбайгаар
            </Button>
            <Button
              size="sm"
              variant={viewMode === "linear" ? "default" : "ghost"}
              onClick={() => setViewMode("linear")}
              className="h-8"
            >
              <LayoutList className="h-4 w-4 mr-1" />
              Жигд
            </Button>
          </div>

          {/* Sort */}
          <Select value={sortBy} onValueChange={(v) => setSortBy(v as SortOption)}>
            <SelectTrigger className="w-[180px]">
              <ArrowUpDown className="h-4 w-4 mr-2" />
              <SelectValue placeholder="Эрэмбэлэх" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="unit_number">Өрөөний дугаар</SelectItem>
              <SelectItem value="area_desc">Талбай (Их → Бага)</SelectItem>
              <SelectItem value="area_asc">Талбай (Бага → Их)</SelectItem>
              <SelectItem value="rent_desc">Түрээс (Их → Бага)</SelectItem>
              <SelectItem value="rent_asc">Түрээс (Бага → Их)</SelectItem>
              <SelectItem value="status">Статус</SelectItem>
            </SelectContent>
          </Select>
        </div>
      </div>

      {/* Statistics Summary */}
      <div className="grid grid-cols-2 md:grid-cols-5 gap-4">
        <Card className="p-3">
          <div className="text-sm text-gray-500">Нийт өрөө</div>
          <div className="text-xl font-bold">{currentFloor?.units.length || 0}</div>
        </Card>
        <Card className="p-3">
          <div className="text-sm text-gray-500">Нийт талбай</div>
          <div className="text-xl font-bold">{totalArea.toFixed(1)}m²</div>
        </Card>
        <Card className="p-3 border-blue-200 bg-blue-50">
          <div className="text-sm text-blue-600">Сул өрөө</div>
          <div className="text-xl font-bold text-blue-700">{statusCounts.vacant}</div>
        </Card>
        <Card className="p-3 border-green-200 bg-green-50">
          <div className="text-sm text-green-600">Эзэмшигчтэй</div>
          <div className="text-xl font-bold text-green-700">{statusCounts.occupied}</div>
        </Card>
        <Card className="p-3 border-yellow-200 bg-yellow-50">
          <div className="text-sm text-yellow-600">Засвартай</div>
          <div className="text-xl font-bold text-yellow-700">{statusCounts.maintenance}</div>
        </Card>
      </div>

      {/* Linear Floor Plan */}
      <Card>
        <CardHeader className="pb-3">
          <CardTitle className="text-base flex items-center justify-between">
            <span>{currentFloor?.name || `${currentFloor?.floor_number}F`}</span>
            <span className="text-sm font-normal text-gray-500">
              {viewMode === "proportional" ? "Талбай харьцаатай харагдац" : "Жигд харагдац"}
            </span>
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="flex flex-wrap gap-3 p-4 bg-gray-50 rounded-lg min-h-[200px]">
            {sortedUnits.map((unit) => (
              <TooltipProvider key={unit.id}>
                <Tooltip delayDuration={200}>
                  <TooltipTrigger asChild>
                    <div
                      className={`
                        rounded-lg border-2 p-3 cursor-pointer transition-all
                        hover:shadow-md hover:scale-105
                        ${STATUS_COLORS[unit.status]}
                        ${viewMode === "linear" ? "flex-1 min-w-[120px] max-w-[200px]" : ""}
                      `}
                      style={
                        viewMode === "proportional"
                          ? { width: getProportionalWidth(unit), flexShrink: 0 }
                          : undefined
                      }
                    >
                      <div className="flex flex-col items-center text-center">
                        <span className="text-lg font-bold">{unit.unit_number}</span>

                        {unit.area_sqm && (
                          <span className="text-sm text-gray-600">{unit.area_sqm}m²</span>
                        )}

                        {unit.status === "occupied" && unit.tenant ? (
                          <span className="text-xs text-gray-600 truncate max-w-full mt-1">
                            {unit.tenant.tenant_type === "company"
                              ? unit.tenant.company_name
                              : unit.tenant.name}
                          </span>
                        ) : (
                          <span className="text-xs mt-1">{UNIT_STATUS_LABELS[unit.status]}</span>
                        )}

                        {unit.monthly_rent > 0 && (
                          <span className="text-xs font-medium mt-1">
                            {formatCurrency(unit.monthly_rent)}
                          </span>
                        )}

                        {unit.status === "occupied" && (
                          <Users className="h-4 w-4 text-green-600 mt-1" />
                        )}
                      </div>
                    </div>
                  </TooltipTrigger>

                  {/* Tooltip Content */}
                  <TooltipContent side="bottom" className="p-0 w-64">
                    <div className="p-3 space-y-2">
                      <div className="font-medium text-base border-b pb-2">
                        {unit.unit_number}
                      </div>

                      <div className="grid grid-cols-2 gap-x-4 gap-y-1 text-sm">
                        <div className="text-gray-500">Статус:</div>
                        <div>{UNIT_STATUS_LABELS[unit.status]}</div>

                        {unit.area_sqm && (
                          <>
                            <div className="text-gray-500">Талбай:</div>
                            <div>{unit.area_sqm}m²</div>
                          </>
                        )}

                        {unit.monthly_rent > 0 && (
                          <>
                            <div className="text-gray-500">Түрээс:</div>
                            <div>{formatCurrency(unit.monthly_rent)}</div>
                          </>
                        )}

                        {unit.tenant && (
                          <>
                            <div className="text-gray-500">Түрээслэгч:</div>
                            <div className="truncate">
                              {unit.tenant.tenant_type === "company"
                                ? unit.tenant.company_name
                                : unit.tenant.name}
                            </div>
                          </>
                        )}
                      </div>

                      {/* Links Section */}
                      <div className="flex flex-col gap-2 pt-2 border-t">
                        <Link
                          href={`/dashboard/properties/${propertyId}/units/${unit.id}`}
                          className="flex items-center gap-2 text-sm text-blue-600 hover:text-blue-800 hover:underline"
                        >
                          <Grid3X3 className="h-4 w-4" />
                          Өрөөний дэлгэрэнгүй
                          <ExternalLink className="h-3 w-3 ml-auto" />
                        </Link>

                        {unit.status === "occupied" && unit.tenant && (
                          <Link
                            href={`/dashboard/tenants/${unit.tenant.id}`}
                            className="flex items-center gap-2 text-sm text-green-600 hover:text-green-800 hover:underline"
                          >
                            <Users className="h-4 w-4" />
                            Түрээслэгч харах
                            <ExternalLink className="h-3 w-3 ml-auto" />
                          </Link>
                        )}

                        {unit.lease && (
                          <Link
                            href={`/dashboard/leases/${unit.lease.id}`}
                            className="flex items-center gap-2 text-sm text-purple-600 hover:text-purple-800 hover:underline"
                          >
                            <FileText className="h-4 w-4" />
                            Гэрээ харах
                            <ExternalLink className="h-3 w-3 ml-auto" />
                          </Link>
                        )}
                      </div>
                    </div>
                  </TooltipContent>
                </Tooltip>
              </TooltipProvider>
            ))}

            {sortedUnits.length === 0 && (
              <div className="w-full text-center py-12 text-gray-500">
                Өрөө бүртгэгдээгүй байна
              </div>
            )}
          </div>
        </CardContent>
      </Card>

      {/* Legend */}
      <FloorPlanLegend />
    </div>
  );
}
