import { Loading } from '@/components/ui/loading';

export default function RootLoading() {
    return <Loading fullPage size="lg" />;
}
